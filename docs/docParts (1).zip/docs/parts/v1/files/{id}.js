module.exports = {
  get: {
    summary: "Serve file",
    responses: {
      200: {
        description: "File"
      },
    },
  },
};
